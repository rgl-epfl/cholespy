from importlib import import_module
import_module('cholespy._cholespy_core')
del import_module
